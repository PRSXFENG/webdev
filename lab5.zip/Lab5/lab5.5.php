<!DOCTYPE html>
<html>
<body>

<form action="lab5.4.php" method="post" ______>
  Select image to upload:
  ______
  ______
</form>

</body>
</html>