<?php
/*
isset() check variable has been initialized && !null
empty() check variable is considered "empty" 
 -> null, 0, false, or an empty string or array
*/

//REQUEST to retreive web form data
//retrieve & checked element's value using ?:
$cust=______

//retrieve & checked element's value using IF..ELSE
______

$type = ______;

//retrieve & checked element's value using ?? (null coalescing operator)
$src1 = ______
$src2 = ______

?>
<p>Customer Name: <?php echo $cust?></p>
<p>Base: ______</p>
<p>Type: ______</p>
<p>Source: ______&nbsp;&nbsp;______</p>
<p>Topping:
<?php
//retrieve data from listbox
$topping = ______
______
$remark=______
$odate=______
$tqvm=______

$delivery = ______
______

?>

<p>Remark: ______</p>
<p>Order Date: ______></p>
<p>ETA: ______</p>
<p>______</p>